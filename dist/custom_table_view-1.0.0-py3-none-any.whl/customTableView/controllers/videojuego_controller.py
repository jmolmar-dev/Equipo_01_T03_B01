# Importa la clase Videojuego para manejar objetos de tipo Videojuego
from customTableView.models.videojuego import Videojuego


class VideojuegoController:
    """Controlador que gestiona la carga y obtención de videojuegos."""

    def __init__(self):
        """Inicializa el controlador con una lista de videojuegos predefinida."""
        self.videojuegos = self.cargar_videojuegos()

    def cargar_videojuegos(self):
        """Carga una lista de objetos Videojuego."""
        return [
            Videojuego("The Legend of Zelda", "Aventura", "Nintendo Switch",
                       "Nintendo", "2017-03-03", "Un juego épico de aventuras."),
            Videojuego("Super Mario Odyssey", "Plataformas", "Nintendo Switch",
                       "Nintendo", "2017-10-27", "Una aventura en 3D de Mario."),
            Videojuego("Elden Ring", "RPG", "Multiplataforma", "FromSoftware",
                       "2022-02-25", "Un mundo abierto con acción y RPG."),
            Videojuego("God of War", "Acción", "PlayStation", "Santa Monica Studio",
                       "2018-04-20", "Kratos en una historia épica en la mitología nórdica.")
        ]

    def obtener_videojuegos(self):
        """Devuelve la lista de videojuegos."""
        return self.videojuegos
