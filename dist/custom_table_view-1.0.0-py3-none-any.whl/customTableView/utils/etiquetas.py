# Archivo: 02_WIDGETS_AVANZADOS\utils\etiquetas.py

# Constante que define el título de la ventana principal
TITULO_VENTANA_PRINCIPAL = "Barra de Búsqueda con Tabla de Videojuegos"

# Constante que define el texto del tooltip para el campo de búsqueda
TOOLTIP_CAMPO_BUSQUEDA = "Búsqueda por código de producto o nombre o descripción o precio o stock o número de ventas"

# Constante que define el texto de marcador de posición (placeholder) para el campo de búsqueda
PLACEHOLDER_CAMPO_BUSQUEDA = TOOLTIP_CAMPO_BUSQUEDA
