# main.py

import sys

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from customButton.views.custom_button import CustomButton

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Configuración de la ventana principal
        self.setWindowTitle("Ventana Principal con CustomButton")
        self.setGeometry(100, 100, 300, 200)

        # Crear una instancia de CustomButton
        button = CustomButton()

        # Crear un layout y añadir el botón
        layout = QVBoxLayout()
        layout.addWidget(button)

        # Crear un widget contenedor y establecer el layout
        container = QWidget()
        container.setLayout(layout)

        # Asignar el contenedor como el widget central de la ventana principal
        self.setCentralWidget(container)


# Función main para ejecutar la aplicación
if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec())

