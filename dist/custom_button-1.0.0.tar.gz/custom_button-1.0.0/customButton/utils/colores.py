#Definimos los colores que emplearemos
BLACK = "#000000"            # Negro
LIGHT_GREEN = "#D9F5DA"       # Verde claro
GREY_BLUE = "#ADAFC1"         # Gris azulado
LIGHT_ORANGE = "#FFE8C0"      # Naranja claro
DARK_PINK = "#CD8888"         # Rosa oscuro
YELLOW_ORANGE = "#FECF49"     # Naranja amarillento
WHITE = "#FFFFFF"             # Blanco
BRIGHT_ORANGE = "#FF5733"     # Naranja brillante
PASTEL_ORANGE = "#FFB07C"     # Naranja pastel
BACKGROUND = "#050D21"  # Color de fondo
ORIGINAL_BUTTON = "#1a67f8"  # Color del botón
GRIS_INTERFAZ = "#c9d5ee"  # Color del hover
