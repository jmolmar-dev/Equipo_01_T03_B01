import os

#1 --> Obtendremos la ruta base del proyecto
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

#2 --> Rutas de nuestros directorios principales
UTILS_DIR = os.path.join(BASE_DIR, 'utils')
VIEWS_DIR = os.path.join(BASE_DIR, 'views')
ICONS_DIR = os.path.join(BASE_DIR, 'icons')
MODELS_DIR = os.path.join(BASE_DIR, 'models')
CONTROLLERS_DIR = os.path.join(BASE_DIR, 'controllers')

#3 --> Rutas especificas a archivos de utils (Colores y al propio archivo)
UTILS_COLORES_PATH = os.path.join(UTILS_DIR, 'colores.py')
UTILS_RUTAS_PATH = os.path.join(UTILS_DIR, 'path.py')

#4 --> Rutas especificas a archivos de views
CUSTOM_QPUSHBUTTON_PATH = os.path.join(VIEWS_DIR, 'custom_button.py')


#5 --> Ruta al archivo main.py en la raiz del proyecto
MAIN_PATH = os.path.join(BASE_DIR, 'main.py')
