#Constante que define el titulo principal de una ventana principal
TITULO_VENTANA_PRINCIPAL = "Barra de Busqueda con Tablas de Videojuegos"
#Constante que define el texto del tolltip para el campo de busqueda
TOOLTIP_CAMPO_BUSQUEDA= "Búsqueda de Videojuego por nombre, id, descripción, genero, plataforma"
#Constante que define el texto de marcador de posicion (placeholder) para el campo de busqueda
PLACEHOLDER_CAMPO_BUSQUEDA = TOOLTIP_CAMPO_BUSQUEDA
