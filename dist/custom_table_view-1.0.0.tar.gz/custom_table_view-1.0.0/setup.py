from setuptools import setup, find_packages

setup(
    name="custom_table_view",
    version="1.0.0",
    packages=find_packages(),  # Encuentra todos los paquetes en el proyecto
    install_requires=[
        "PySide6==6.7.2"
    ],
    author="Juan Molero",
    author_email="jmolmar984@iescarrillo.es",
    description="Componente basado en una tabla donde se mostraran los resultados de la barra de busqueda",
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.12",
)
