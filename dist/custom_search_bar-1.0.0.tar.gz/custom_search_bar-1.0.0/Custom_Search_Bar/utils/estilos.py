#Definiremos colores para el uso general de la aplicacion en modo oscuro
DARK_BACKGROUND = "#1E1E1E"
DARK_GREY = "#2E2E2E"
SOFT_WHITE = "#D9D9D9"
ACCENT_BLUE = "#4A90E2"
DARK_GREEN = "#1B5E20"
ACCENT_ORANGE = "#FF8C42"
DEEP_RED = "#D32F2F"
BORDER_COLOR = ACCENT_BLUE

#Estilo para el campo de texto
ESTILO_CAMPO_TEXTO = f"""
    color: {SOFT_WHITE};  
    background-color: {DARK_BACKGROUND}; 
    border: 1px solid {ACCENT_ORANGE};  
    border-radius: 5px;  
    padding: 5px;  
"""

ESTILO_TABLA = f"""
    QTableView {{
        background-color: {DARK_BACKGROUND};  /* Color de fondo de la tabla */
        color: {SOFT_WHITE};  /* Color del texto */
        gridline-color: {BORDER_COLOR};  /* Color de las líneas de la cuadrícula */
        /* border: 1px solid {BORDER_COLOR}; */  /* Borde opcional */
        selection-color: {DARK_BACKGROUND};  /* Color del texto en la celda seleccionada */
    }}

    QHeaderView::section {{
        background-color: {ACCENT_BLUE};  /* Color de fondo del encabezado */
        color: {SOFT_WHITE};  /* Color del texto del encabezado */
        padding: 5px;  /* Espaciado interno en las secciones del encabezado */
        border: 1px solid {BORDER_COLOR};  /* Borde de las secciones del encabezado */
    }}

    QTableCornerButton::section {{
        background-color: {ACCENT_BLUE};  /* Color de fondo del botón de la esquina */
        border: 1px solid {BORDER_COLOR};  /* Borde del botón de la esquina */
    }}

    QTableView::item:selected {{
        background-color: {ACCENT_ORANGE};  /* Color de fondo para celdas seleccionadas */
        color: {DARK_BACKGROUND};  /* Color del texto en la celda seleccionada */
    }}
"""



