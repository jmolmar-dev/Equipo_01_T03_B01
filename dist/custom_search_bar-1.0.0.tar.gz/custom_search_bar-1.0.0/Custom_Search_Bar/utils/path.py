import os

#1 --> Obtener la ruta base del proyecto:
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#2 --> Rutas de los directorios principales en nuestro proyecto:
UTILS_DIR = os.path.join(BASE_DIR, 'utils_searchBar')
VIEWS_DIR = os.path.join(BASE_DIR, 'views_searchBar')
ICONS_DIR = os.path.join(BASE_DIR, 'icons_searchBar')
CONTROLLER_DIR = os.path.join(BASE_DIR, 'controller')
MODELS_DIR = os.path.join(BASE_DIR, 'models')


#3 --> Rutas Especificas a archivos de Utils
UTILS_COLORES_PATH = os.path.join(BASE_DIR, 'colores.py')
UTILS_PATH = os.path.join(BASE_DIR, 'path.py') #Ruta al propio archivo

#4 --> Rutas Especificas a archivos de Views
CUSTOM_QSEARCHBAR_PATH = os.path.join(VIEWS_DIR, 'custom_search_bar.py')

#5 --> Ruta al archivo main_searchBar.py en la raiz del proyecto
MAIN_PATH = os.path.join(BASE_DIR, 'main_searchBar.py')

#Rutas especificas para los iconos
SEARCH_ICON_PATH = os.path.join(os.path.dirname(BASE_DIR), 'icons', 'search_icon.png')
TRASH_ICON_PATH = os.path.join(os.path.dirname(BASE_DIR), 'icons', 'trash_icon.png')
